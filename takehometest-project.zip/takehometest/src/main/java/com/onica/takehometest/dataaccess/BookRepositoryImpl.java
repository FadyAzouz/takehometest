package com.onica.takehometest.dataaccess;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.onica.takehometest.domain.BookModel;

@Component
public class BookRepositoryImpl implements BookRepository {

	@Autowired
	private BookReader bookReader;

	@Override
	public List<BookModel> findAll() throws IOException {

		return bookReader.readBookFromFile();
	}

	@Override
	public BookModel findById(List<BookModel> retrievedBookList, String id) {
		return retrievedBookList == null ? null
				: retrievedBookList.stream().filter(item -> item.getId().equals(id)).findFirst().orElse(null);
	}

	@Override
	public List<Object> save(List<BookModel> retrievedBookList, BookModel book) {
		List<Object> returnedList = new ArrayList<>();
		List<String> idList = retrievedBookList.stream().map(item -> item.getId()).collect(Collectors.toList());
		book.setId(getUniqueIdNumber(idList));
		retrievedBookList.add(book);
		returnedList.add(retrievedBookList);
		returnedList.add(book.getId());
		return returnedList;
	}

	@Override
	public void saveAll(List<BookModel> bookList) throws IOException {
		bookReader.writeBookToFile(bookList);
	}

	@Override
	public List<BookModel> updateBookById(List<BookModel> retrievedBookList, BookModel updatedBook) {
		for (int index = 0; index < retrievedBookList.size(); index++) {
			if (retrievedBookList.get(index).getId().equals(updatedBook.getId())) {
				if (updatedBook.getAuthor() != null) {
					retrievedBookList.get(index).setAuthor(updatedBook.getAuthor());
				}
				if (updatedBook.getTitle() != null) {
					retrievedBookList.get(index).setTitle(updatedBook.getTitle());
				}
				if (updatedBook.getDescription() != null) {
					retrievedBookList.get(index).setDescription(updatedBook.getDescription());
				}
			}
		}
		return retrievedBookList;
	}

	@Override
	public List<BookModel> findByTitleContaining(List<BookModel> retrievedBookList, String title) {
		return retrievedBookList == null ? null
				: retrievedBookList.stream().filter(item -> item.getTitle().contains(title))
						.collect(Collectors.toList());
	}

	@Override
	public String getUniqueIdNumber(List<String> idList) {
		Random random = new Random();
		int randomId = random.nextInt(100);
		String newId = String.valueOf(randomId);
		while (idList.contains(newId)) {
			randomId = random.nextInt(100);
		}
		newId = String.valueOf(randomId);
		return newId;
	}
}
