package com.onica.takehometest.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onica.takehometest.dataaccess.BookRepository;
import com.onica.takehometest.domain.BookModel;

@Service("bookService")
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookRepository;

	static final Logger logger = Logger.getLogger(BookServiceImpl.class);

	@Override
	public List<BookModel> getAllBooks() {
		// Read books from text file
		try {
			return bookRepository.findAll();
		} catch (IOException e) {
			logger.error("Error while reading all data from file");
		}
		return new ArrayList<>();
	}

	@Override
	public BookModel getBookById(List<BookModel> retrievedBookList, String id) {
		return bookRepository.findById(retrievedBookList, id);
	}

	@Override
	public List<Object> createBook(List<BookModel> retrievedBookList, BookModel book) {
		return bookRepository.save(retrievedBookList, book);
	}

	@Override
	public void createBookList(List<BookModel> bookList) {
		// Save books to text file
		try {
			bookRepository.saveAll(bookList);
		} catch (IOException e) {
			logger.error("Error while saving data to file " + e.getMessage());
		}
	}

	@Override
	public List<BookModel> updateBook(List<BookModel> retrievedBookList, BookModel updatedBook) {
		return bookRepository.updateBookById(retrievedBookList, updatedBook);
	}

	@Override
	public List<BookModel> findBookLikeTitle(List<BookModel> retrievedBookList, String title) {
		return bookRepository.findByTitleContaining(retrievedBookList, title);
	}

	@Override
	public boolean isInputValid(List<BookModel> retrievedBookList, String id) {
		List<BookModel> checkedBookList = retrievedBookList.stream().filter(item -> item.getId().equals(id))
				.collect(Collectors.toList());
		return !checkedBookList.isEmpty();
	}

}
