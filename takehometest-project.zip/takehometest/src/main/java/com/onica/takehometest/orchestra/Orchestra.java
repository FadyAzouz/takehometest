package com.onica.takehometest.orchestra;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.onica.takehometest.domain.BookModel;
import com.onica.takehometest.service.BookServiceImpl;

@Component
public class Orchestra {

	static final Logger logger = Logger.getLogger(Orchestra.class);

	@Autowired
	@Qualifier("bookService")
	private BookServiceImpl bookService;

	@SuppressWarnings("unchecked")
	public void mainOrchestra() {
		List<BookModel> retrievedBookList = bookService.getAllBooks();
		logger.info("Loaded data from file successfully\n");

		Scanner scanner = new Scanner(System.in);
		boolean more = true;

		try {
			logger.info("\n==== Book Manager ==== \n");
			logger.info("     1) View all books\r\n" + "     2) Add a book\r\n" + "     3) Edit a book\r\n"
					+ "     4) Search for a book\r\n" + "     5) Save and exit\r\n");
			logger.info("\nChoose [1-5]: ");
			do {
				String selectedOption = scanner.nextLine();

				// Choose Option 1 handling
				if (selectedOption.equals("1")) {

					logger.info("\n==== View Books ==== \n");
					retrievedBookList.forEach(retrievedBook -> logger
							.info(String.format("     %n[%s] %s", retrievedBook.getId(), retrievedBook.getTitle())));
					getBookDetails(retrievedBookList);

					// Choose Option 2 handling
				} else if (selectedOption.equals("2")) {
					logger.info("\n==== Add a Book ==== \n");
					BookModel book = new BookModel();
					logger.info("\nPlease enter the following information:\n");
					logger.info("\nTitle: ");
					book.setTitle(scanner.nextLine());
					logger.info("\nAuthor:");
					book.setAuthor(scanner.nextLine());
					logger.info("\nDescription:");
					book.setDescription(scanner.nextLine());
					List<Object> objectList = bookService.createBook(retrievedBookList, book);
					retrievedBookList = (List<BookModel>) objectList.get(0);
					logger.info(String.format("%nBook [%s] Saved%n", objectList.get(1)));

					// Choose Option 3 handling
				} else if (selectedOption.equals("3")) {
					logger.info("\n==== Edit a Book ==== \n");
					retrievedBookList.forEach(retrievedBook -> logger
							.info(String.format("     %n[%s] %s", retrievedBook.getId(), retrievedBook.getTitle())));
					retrievedBookList = updateBookById(retrievedBookList);

					// Choose Option 4 handling
				} else if (selectedOption.equals("4")) {
					logger.info("\n==== Search ==== \n");
					logger.info("\nType in one or more keywords to search for\n\n");
					searchBookByTitle(retrievedBookList);

					// Choose Option 5 handling
				} else if (selectedOption.equals("5")) {
					saveAndClose(retrievedBookList);
					logger.info("Library saved.");
					return;
				} else {
					logger.info("Wrong Choice");
				}
				logger.info("\n==== Book Manager ====\n");
				logger.info("\n     1) View all books\r\n" + "     2) Add a book\r\n" + "     3) Edit a book\r\n"
						+ "     4) Search for a book\r\n" + "     5) Save and exit\r\n");
				logger.info("\nChoose [1-5]: ");
			} while (more);
		} finally {
			scanner.close();
		}

	}

	private List<BookModel> updateBookById(List<BookModel> retrievedBookList) {

		Scanner scanner = new Scanner(System.in);
		boolean more = true;
		BookModel retrievedBook;
		BookModel newBook = new BookModel();
		String selectedOption = null;
		boolean changed = false;
		String id;
		do {
			logger.info("\n\nEnter the book ID of the book you want to edit; to return press <Enter>.\n");
			logger.info(String.format("%nBook ID: "));
			selectedOption = scanner.nextLine();
			if (selectedOption.trim().equals("")) {
				return retrievedBookList;
			}
			if (!checkInputId(retrievedBookList, selectedOption)) {
				logger.info("\nInvalid Option");
				continue;
			}
			logger.info("\nInput the following information. To leave a field unchanged, hit <Enter>.\n");
			id = selectedOption;
			retrievedBook = bookService.getBookById(retrievedBookList, id);
			logger.info(String.format("%n    Title [%s]: ", retrievedBook.getTitle()));
			selectedOption = scanner.nextLine();
			if (!selectedOption.trim().equals("")) {
				newBook.setTitle(selectedOption);
				changed = true;
			}
			logger.info(String.format("    Author [%s]: ", retrievedBook.getAuthor()));
			selectedOption = scanner.nextLine();
			if (!selectedOption.trim().equals("")) {
				newBook.setAuthor(selectedOption);
				changed = true;
			}
			logger.info(String.format("    Description [%s]: ", retrievedBook.getDescription()));
			selectedOption = scanner.nextLine();
			if (!selectedOption.trim().equals("")) {
				newBook.setDescription(selectedOption);
				changed = true;
			}
			if (changed) {
				newBook.setId(id);
				retrievedBookList = bookService.updateBook(retrievedBookList, newBook);
				logger.info("\nBook saved.\n");

			}
		} while (more);
		scanner.close();
		return retrievedBookList;
	}

	private void getBookDetails(List<BookModel> retrievedBookList) {

		logger.info("\n\nTo view details enter the book ID, to return press <Enter>.");
		logger.info(String.format("%n%nBook ID: "));
		Scanner scanner = new Scanner(System.in);
		boolean more = true;
		BookModel retrievedBook;
		String selectedOption = null;
		do {
			selectedOption = scanner.nextLine();
			if (String.valueOf(selectedOption).trim().equals("")) {
				return;
			}
			if (!checkInputId(retrievedBookList, selectedOption)) {
				logger.info("\nInvalid Option");
				logger.info(String.format("%n%nBook ID: "));
				continue;
			}
			retrievedBook = bookService.getBookById(retrievedBookList, selectedOption);
			if (retrievedBook != null) {
				logger.info(String.format("%n    ID: %s", retrievedBook.getId()));
				logger.info(String.format("%n    Title: %s", retrievedBook.getTitle()));
				logger.info(String.format("%n    Author: %s", retrievedBook.getAuthor()));
				logger.info(String.format("%n    Description: %s", retrievedBook.getDescription()));
				logger.info("\n\nTo view details enter the book ID, to return press <Enter>.");
				logger.info(String.format("%n%nBook ID: "));
			} else {
				logger.info(String.format("No Book found with ID: %s", selectedOption));
			}

		} while (more);
		scanner.close();
	}

	private void searchBookByTitle(List<BookModel> retrievedBookList) {

		logger.info("    Search: ");
		Scanner scanner = new Scanner(System.in);
		boolean more = true;
		List<BookModel> resultBookList;
		String selectedOption = null;
		selectedOption = scanner.nextLine();
		resultBookList = bookService.findBookLikeTitle(retrievedBookList, selectedOption);
		if (resultBookList.isEmpty()) {
			logger.info(String.format("No Book found with Title: %s", selectedOption));
			return;
		} else {
			logger.info(
					"\nThe following books matched your query. Enter the book ID to see more details, or <Enter> to return.\n");
			for (BookModel bookModel : resultBookList) {
				logger.info(String.format("%n    [%s] %s", bookModel.getId(), bookModel.getTitle()));
			}
			do {
				logger.info("\n\nBook ID: ");
				selectedOption = scanner.nextLine();
				if (selectedOption.trim().equals("")) {
					return;
				}
				if (!checkInputId(retrievedBookList, selectedOption)) {
					logger.info("\nInvalid Option");
					logger.info(String.format("%n%nBook ID: "));
					continue;
				} else {
					BookModel retrievedBook = bookService.getBookById(retrievedBookList, selectedOption);
					logger.info(String.format("%n    ID: %s", retrievedBook.getId()));
					logger.info(String.format("%n    Title: %s", retrievedBook.getTitle()));
					logger.info(String.format("%n    Author: %s", retrievedBook.getAuthor()));
					logger.info(String.format("%n    Description: %s", retrievedBook.getDescription()));
				}

			} while (more);
			scanner.close();
		}
	}

	private void saveAndClose(List<BookModel> retrievedBookList) {
		bookService.createBookList(retrievedBookList);
	}

	private boolean checkInputId(List<BookModel> retrievedBookList, String id) {
		return bookService.isInputValid(retrievedBookList, id);
	}

}