package com.onica.takehometest.dataaccess;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.onica.takehometest.domain.BookModel;
import com.onica.takehometest.shared.common.Constants;

@Component
public class BookReader {

	public List<BookModel> readBookFromFile() throws IOException {
		BookModel retrievedBook = null;
		List<BookModel> retrievedBookList = new ArrayList<>();
		
	         InputStream i = BookReader.class.getResourceAsStream(Constants.INPUTFILEPATH);
	         BufferedReader readFile = new BufferedReader(new InputStreamReader(i));
			String line;
			while ((line = readFile.readLine()) != null) {
				String[] split = line.split(",", 4);
				if (split.length != 4) { // Not enough tokens (e.g., empty line) read
					continue;
				}
				retrievedBook = new BookModel();
				retrievedBook.setId(split[0]);
				retrievedBook.setTitle(split[1]);
				retrievedBook.setAuthor(split[2]);
				retrievedBook.setDescription(split[3]);
				retrievedBookList.add(retrievedBook);
			}
			return retrievedBookList;
		
	}

	public void writeBookToFile(List<BookModel> bookList) throws IOException {
		String userPath= System.getProperty("user.home");
		String sp = File.separator;
		String completePath = userPath + sp 
                + Constants.OUTPUTFILEPATH;
		File file = new File(completePath);
		FileWriter fw = new FileWriter(file);
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			for (BookModel book : bookList) {
				bw.write(book.toString());
				bw.newLine();
			}
		} finally {
			bw.close();
		}
	}
}
