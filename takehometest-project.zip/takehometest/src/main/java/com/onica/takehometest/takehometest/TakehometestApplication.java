package com.onica.takehometest.takehometest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.onica.takehometest.appconfig.AppConfig;
import com.onica.takehometest.orchestra.Orchestra;

@SpringBootApplication
public class TakehometestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TakehometestApplication.class, args);
		AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfig.class);
		Orchestra orchestra = appContext.getBean(Orchestra.class);

		orchestra.mainOrchestra();
		appContext.close();

	}

}
