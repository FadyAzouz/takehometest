package com.onica.takehometest.shared.common;

public class Constants {

	private Constants() {

    }
	
	public static final String OUTPUTFILEPATH = "outputData.txt";
	public static final String INPUTFILEPATH = "/inputData.txt";
}
