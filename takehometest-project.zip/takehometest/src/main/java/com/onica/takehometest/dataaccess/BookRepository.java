package com.onica.takehometest.dataaccess;

import java.io.IOException;
import java.util.List;
import com.onica.takehometest.domain.BookModel;

public interface BookRepository {

	List<BookModel> findAll() throws IOException;

	BookModel findById(List<BookModel> retrievedBookList, String id);

	List<Object> save(List<BookModel> retrievedBookList, BookModel book);

	String getUniqueIdNumber(List<String> idList);

	void saveAll(List<BookModel> bookList) throws IOException;

	List<BookModel> updateBookById(List<BookModel> retrievedBookList, BookModel updatedBook);

	List<BookModel> findByTitleContaining(List<BookModel> retrievedBookList, String title);
}
