package com.onica.takehometest.takehometest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TakehometestApplicationTests {

	@Test
	void contextLoads() {
	}

}
